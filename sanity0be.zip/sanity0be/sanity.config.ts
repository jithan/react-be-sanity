import { defineConfig } from 'sanity'
import { structureTool } from 'sanity/structure'
import { visionTool } from '@sanity/vision'
import { documentInternationalization } from '@sanity/document-internationalization'
import { assist } from '@sanity/assist'
import { schemaTypes } from './schemaTypes'

export default defineConfig({
  name: 'default',
  title: 'Sanity POC studio',

  projectId: 'lyl5ivou',
  dataset: 'production',

  plugins: [
    structureTool(),
    visionTool(),

    // 🌍 i18n (correct)
    documentInternationalization({
      supportedLanguages: [
        { id: 'en', title: 'English' },
        { id: 'de', title: 'German' },
      ],
      schemaTypes: ['services', 'article', 'page'],
    }),

    // 🤖 AI assist (optional)
    assist({
      translate: {
        document: {
          languages: [
            { id: 'en', title: 'English' },
            { id: 'de', title: 'German' },
          ],
          documentTypes: ['services', 'article', 'page'],
        },
      },
    }),
  ],

  schema: {
    types: schemaTypes,
  },
})