import {defineField, defineType} from 'sanity'
import {MdWeb as icon} from 'react-icons/md'

export default defineType({
  name: 'page',
  title: 'Page',
  type: 'document',
  icon,

  fields: [
    // 🌍 Language (auto-managed)
    defineField({
      name: 'language',
      title: 'Language',
      type: 'string',
      readOnly: true,
      hidden: true,
    }),

    // 📝 Title
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),

    // 🔗 Slug
    defineField({
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      options: {
        source: 'title',
        maxLength: 100,
      },
      validation: (rule) => rule.required(),
    }),

    // 📌 Header menu toggle
    defineField({
      name: 'showInHeaderMenu',
      title: 'Show in Header Menu',
      type: 'boolean',
      initialValue: false,
    }),

    // 🏷️ Menu Title
    defineField({
      name: 'menuTitle',
      title: 'Menu Title',
      type: 'string',
      description: 'Defaults to page title',
      hidden: ({ parent }) => !parent?.showInHeaderMenu,
    }),

    // 🔢 Menu order
    defineField({
      name: 'menuOrder',
      title: 'Menu Order',
      type: 'number',
      hidden: ({ parent }) => !parent?.showInHeaderMenu,
      validation: (rule) => rule.min(0).integer(),
    }),

    // 🧩 Page Builder
    defineField({
      name: 'content',
      title: 'Page Content',
      type: 'pageBuilder',
    }),

    // 🔍 SEO
    defineField({
      name: 'seo',
      title: 'SEO Settings',
      type: 'object',
      fields: [
        defineField({
          name: 'metaTitle',
          title: 'Meta Title',
          type: 'string',
        }),
        defineField({
          name: 'metaDescription',
          title: 'Meta Description',
          type: 'text',
          rows: 3,
        }),
        defineField({
          name: 'ogImage',
          title: 'Open Graph Image',
          type: 'image',
          options: {hotspot: true},
        }),
      ],
    }),
  ],

  preview: {
    select: {
      title: 'title',
      slug: 'slug.current',
      showInHeaderMenu: 'showInHeaderMenu',
      menuTitle: 'menuTitle',
      language: 'language',
    },
    prepare({ title, slug, showInHeaderMenu, menuTitle, language }) {
      const displayTitle = showInHeaderMenu
        ? `${title || 'Untitled'} 📍`
        : title || 'Untitled'

      const subtitle = showInHeaderMenu
        ? `${language || 'no-lang'} | /${slug || ''} • Menu: ${menuTitle || title}`
        : `${language || 'no-lang'} | /${slug || ''}`

      return {
        title: displayTitle,
        subtitle,
      }
    },
  },
})