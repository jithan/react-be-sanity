import { defineType, defineField } from 'sanity'
import { DocumentsIcon } from '@sanity/icons'

export default defineType({
  name: 'services',
  title: 'Services',
  type: 'document',
  icon: DocumentsIcon,

  fields: [
    // 📝 TITLE
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (Rule) => Rule.required().max(180),
    }),

    // 🔗 SLUG (SAFE i18n VERSION)
    defineField({
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      options: {
        source: 'title',
        maxLength: 96,

        // ✅ FINAL SAFE UNIQUE VALIDATION
        isUnique: async (slug, context) => {
          const { document, getClient } = context

          if (!slug) return true

          const client = getClient({ apiVersion: '2023-01-01' })

          const id = document?._id?.replace(/^drafts\./, '')

          // ✅ SAFE LANG FALLBACK
          const lang = document?.__i18n_lang || 'en'

          try {
            const result = await client.fetch(
              `count(*[
                _type == "services" &&
                slug.current == $slug &&
                __i18n_lang == $lang &&
                !(_id in [$id, "drafts." + $id])
              ]) == 0`,
              { slug, id, lang }
            )

            return result
          } catch (err) {
            console.error('Slug validation error:', err)

            // ✅ Prevent studio crash
            return true
          }
        },
      },

      validation: (Rule) => Rule.required(),
    }),

    // 📅 PUBLISHED DATE
    defineField({
      name: 'publishedAt',
      title: 'Published at',
      type: 'datetime',
      initialValue: () => new Date().toISOString(),
    }),

    // ✍️ EXCERPT
    defineField({
      name: 'excerpt',
      title: 'Excerpt',
      type: 'text',
      rows: 3,
      validation: (Rule) => Rule.max(220),
    }),

    // 🧩 COMPONENTS
    defineField({
      name: 'components',
      title: 'Page Components',
      type: 'array',
      of: [
        { type: 'Heroimage' },
        { type: 'Anchor_links' },
        { type: 'FullwidthImage' },
        { type: 'SpotlightContentService' },
        { type: 'twoColumn' },
        { type: 'topicsSection' },
        { type: 'accordionGroup' },
        { type: 'searchBlock' },
      ],
      validation: (Rule) => Rule.required().min(1),
      options: { sortable: true },
    }),
  ],

  preview: {
    select: {
      title: 'title',
      slug: 'slug.current',
    },
    prepare({ title, slug }) {
      return {
        title: title || 'Untitled',
        subtitle: slug ? `/${slug}` : 'No slug',
      }
    },
  },
})