// schemas/objects/link.ts
import { defineType, defineField } from 'sanity'

export default defineType({
  name: 'link',
  title: 'Link',
  type: 'object',

  fields: [
    // ✅ plain string instead of internationalized
    defineField({
      name: 'label',
      title: 'Label',
      type: 'string',
      validation: (Rule) => Rule.required().max(160),
    }),

    defineField({
      name: 'url',
      title: 'URL',
      type: 'url',
      validation: (Rule) =>
        Rule.uri({
          allowRelative: true,
          scheme: ['http', 'https', 'mailto', 'tel'],
        }),
    }),

    defineField({
      name: 'openInNewTab',
      title: 'Open in new tab',
      type: 'boolean',
    }),
  ],
})