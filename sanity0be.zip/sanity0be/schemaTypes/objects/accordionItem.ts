import { defineType, defineField } from "sanity";

export default defineType({
  name: "accordionItem",
  title: "Accordion Item",
  type: "object",

  fields: [
    // 🆔 Optional ID (anchor / analytics)
    defineField({
      name: "componentId",
      title: "Component ID",
      type: "string",
      description: "Optional unique ID (used for anchor linking or tracking).",
    }),

    // 📝 Title
    defineField({
      name: "title",
      title: "Title",
      type: "string",
      validation: (Rule) => Rule.required().max(120),
    }),

    // 🖼️ Icon (optional)
    defineField({
      name: "icon",
      title: "Icon",
      type: "image",
      options: { hotspot: true },
      fields: [
        defineField({
          name: "alt",
          title: "Alt text",
          type: "string",
          validation: (Rule) => Rule.max(120),
        }),
      ],
    }),

    // 📄 Description (reuse blockContent)
    defineField({
      name: "description",
      title: "Description",
      type: "blockContent", // ✅ reusable
      validation: (Rule) => Rule.required(),
    }),
  ],

  preview: {
    select: {
      title: "title",
      id: "componentId",
    },
    prepare({ title, id }) {
      return {
        title: title || "Accordion Item",
        subtitle: id ? `ID: ${id}` : "Accordion content",
      };
    },
  },
});