import { defineType, defineField } from 'sanity'
import { SparkleIcon } from '@sanity/icons'

export default defineType({
  name: 'SpotlightContentService',
  title: 'Spotlight content & Service',
  type: 'object',
  icon: SparkleIcon,

  fields: [
    // Type
    defineField({
      name: 'spotlight_content',
      title: 'Spotlight content',
      type: 'string',
      options: {
        list: [
          { title: 'Service', value: 'service' },
          { title: 'Content', value: 'content' },
        ],
      },
      validation: (Rule) => Rule.required(),
      initialValue: 'service',
    }),

    // Component ID
    defineField({
      name: 'field_component_id',
      title: 'Component ID',
      type: 'string',
      validation: (Rule) => Rule.max(120),
    }),

    // Anchor ID
    defineField({
      name: 'data_id_for_anchor_linking',
      title: 'Data ID for anchor linking',
      type: 'string',
      validation: (Rule) =>
        Rule.regex(/^[A-Za-z][-A-Za-z0-9_:.]*$/).error('Invalid HTML id'),
    }),

    // ✅ Plain Title (NO locale)
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (Rule) => Rule.max(180),
    }),

    // Background
    defineField({
      name: 'background_color',
      title: 'Background Color',
      type: 'string',
      options: {
        list: [
          { title: 'White', value: 'white' },
          { title: 'Light Gray', value: 'light-gray' },
          { title: 'Teal', value: 'teal' },
          { title: 'Dark', value: 'dark' },
        ],
      },
      initialValue: 'white',
    }),

    // Alignment
    defineField({
      name: 'image_alignment',
      title: 'Image Alignment',
      type: 'string',
      options: {
        list: [
          { title: 'Left', value: 'left' },
          { title: 'Right', value: 'right' },
          { title: 'Center', value: 'center' },
        ],
      },
      initialValue: 'right',
    }),

    // Image
    defineField({
      name: 'image',
      title: 'Image',
      type: 'image',
      options: { hotspot: true },
      fields: [
        defineField({
          name: 'alt',
          title: 'Alt text',
          type: 'string', // ✅ plain
          validation: (Rule) => Rule.required().min(5).max(160),
        }),
      ],
    }),

    // Logo
    defineField({
      name: 'logo_or_service_pillar',
      title: 'Logo / Service Pillar',
      type: 'image',
      options: { hotspot: true },
      fields: [
        defineField({
          name: 'alt',
          title: 'Alt text',
          type: 'string', // ✅ plain
        }),
      ],
    }),

    // Link
    defineField({
      name: 'link',
      title: 'Link',
      type: 'object',
      fields: [
        defineField({
          name: 'url',
          title: 'URL',
          type: 'url',
        }),
        defineField({
          name: 'label',
          title: 'Label',
          type: 'string', // ✅ plain
        }),
      ],
    }),
  ],

  preview: {
    select: {
      title: 'title',
      kind: 'spotlight_content',
      media: 'image',
      align: 'image_alignment',
    },
    prepare({ title, kind, media, align }) {
      return {
        title: title || 'Spotlight content & Service',
        subtitle: `${kind || 'Spotlight'}${align ? ` · ${align}` : ''}`,
        media,
      }
    },
  },
})