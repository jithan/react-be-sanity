import {defineType, defineField} from 'sanity'

export default defineType({
  name: 'CustomImage',
  title: 'Image',
  type: 'object',

  fields: [
    // 🖼️ Image
    defineField({
      name: 'image',
      title: 'Image',
      type: 'image',
      options: { hotspot: true },
      validation: (Rule) => Rule.required(),
    }),

    // ♿ Alt text (IMPORTANT)
    defineField({
      name: 'alt',
      title: 'Alt text',
      type: 'string',
      description: 'Describe the image for accessibility',
      validation: (Rule) =>
        Rule.required()
          .min(5)
          .max(160)
          .warning('Alt text should be meaningful'),
    }),

    // 📸 Caption (NEW 🔥)
    defineField({
      name: 'caption',
      title: 'Caption',
      type: 'string',
      description: 'Optional caption below image',
    }),

    // 📐 Aspect ratio (design control 🔥)
    defineField({
      name: 'aspectRatio',
      title: 'Aspect Ratio',
      type: 'string',
      options: {
        list: [
          { title: 'Auto', value: 'auto' },
          { title: '1:1 (Square)', value: '1:1' },
          { title: '4:3', value: '4:3' },
          { title: '16:9', value: '16:9' },
        ],
      },
      initialValue: 'auto',
    }),

    // 🎯 Alignment (NEW 🔥)
    defineField({
      name: 'alignment',
      title: 'Alignment',
      type: 'string',
      options: {
        list: [
          { title: 'Left', value: 'left' },
          { title: 'Center', value: 'center' },
          { title: 'Right', value: 'right' },
        ],
      },
      initialValue: 'center',
    }),

    // 🔗 Link (image clickable)
    defineField({
      name: 'link',
      title: 'Link',
      type: 'link',
      description: 'Optional link when clicking the image',
    }),

    // 🎨 Variant (design system 🔥)
    defineField({
      name: 'variant',
      title: 'Variant',
      type: 'string',
      options: {
        list: [
          { title: 'Default', value: 'default' },
          { title: 'Rounded', value: 'rounded' },
          { title: 'Shadow', value: 'shadow' },
        ],
      },
      initialValue: 'default',
    }),
  ],

  preview: {
    select: {
      media: 'image',
      title: 'alt',
      caption: 'caption',
    },
    prepare({media, title, caption}) {
      return {
        title: title || 'Image',
        subtitle: caption || 'No caption',
        media,
      }
    },
  },
})