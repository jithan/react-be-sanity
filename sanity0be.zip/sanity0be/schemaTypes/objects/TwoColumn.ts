import { defineType, defineField } from 'sanity'
import { SplitHorizontalIcon } from '@sanity/icons'

const columnContent = [
  { type: 'CustomImage' },
  { type: 'htmlBlock' },
  { type: 'link' },
]

export default defineType({
  name: 'twoColumn',
  title: 'Two Column',
  type: 'object',
  icon: SplitHorizontalIcon,

  fields: [
    // 🆔 Component ID
    defineField({
      name: 'componentId',
      title: 'Component ID',
      type: 'string',
      validation: (Rule) => Rule.max(120),
    }),

    // 🔗 Anchor ID
    defineField({
      name: 'anchorId',
      title: 'Anchor ID',
      type: 'string',
      validation: (Rule) =>
        Rule.regex(/^[A-Za-z][-A-Za-z0-9_:.]*$/),
    }),

    // 📐 Layout
    defineField({
      name: 'layout',
      title: 'Column Layout',
      type: 'string',
      options: {
        list: [
          { title: '50 / 50', value: '50-50' },
          { title: '60 / 40', value: '60-40' },
          { title: '40 / 60', value: '40-60' },
        ],
      },
      initialValue: '50-50',
    }),

    defineField({
      name: 'verticalAlign',
      title: 'Vertical Alignment',
      type: 'string',
      options: {
        list: [
          { title: 'Top', value: 'start' },
          { title: 'Center', value: 'center' },
          { title: 'Bottom', value: 'end' },
        ],
      },
      initialValue: 'start',
    }),

    defineField({
      name: 'reverseOnMobile',
      title: 'Reverse on Mobile',
      type: 'boolean',
      initialValue: false,
    }),

    // 🎨 Theme
    defineField({
      name: 'background',
      title: 'Background',
      type: 'string',
      options: {
        list: [
          { title: 'Default', value: 'default' },
          { title: 'Subtle', value: 'subtle' },
          { title: 'Primary', value: 'primary' },
          { title: 'Dark', value: 'dark' },
        ],
      },
      initialValue: 'default',
    }),

    defineField({
      name: 'spacing',
      title: 'Spacing',
      type: 'string',
      options: {
        list: [
          { title: 'None', value: 'none' },
          { title: 'Small', value: 'sm' },
          { title: 'Medium', value: 'md' },
          { title: 'Large', value: 'lg' },
        ],
      },
      initialValue: 'md',
    }),

    defineField({
      name: 'gap',
      title: 'Column Gap',
      type: 'string',
      options: {
        list: [
          { title: 'None', value: 'none' },
          { title: 'Small', value: 'sm' },
          { title: 'Medium', value: 'md' },
          { title: 'Large', value: 'lg' },
        ],
      },
      initialValue: 'md',
    }),

    defineField({
      name: 'border',
      title: 'Border',
      type: 'string',
      options: {
        list: [
          { title: 'None', value: 'none' },
          { title: 'Top', value: 'top' },
          { title: 'Bottom', value: 'bottom' },
          { title: 'Both', value: 'both' },
        ],
      },
      initialValue: 'none',
    }),

    // 🧩 Left column
    defineField({
      name: 'left',
      title: 'Left Column',
      type: 'array',
      of: columnContent,
      validation: (Rule) => Rule.required().min(1).max(5),
      options: { sortable: true },
    }),

    // 🧩 Right column
    defineField({
      name: 'right',
      title: 'Right Column',
      type: 'array',
      of: columnContent,
      validation: (Rule) => Rule.required().min(1).max(5),
      options: { sortable: true },
    }),

    // ♿ Accessibility
    defineField({
      name: 'ariaLabel',
      title: 'ARIA Label',
      type: 'string',
    }),
  ],

  preview: {
    select: {
      left: 'left',
      right: 'right',
      layout: 'layout',
    },
    prepare({ left, right, layout }) {
      return {
        title: 'Two Column Section',
        subtitle: `${layout} | Left: ${left?.length || 0} items | Right: ${right?.length || 0} items`,
      }
    },
  },
})