import { defineType, defineField } from 'sanity'
import { CodeBlockIcon } from '@sanity/icons'

export default defineType({
  name: 'htmlBlock',
  title: 'HTML Block',
  type: 'object',
  icon: CodeBlockIcon,

  groups: [
    { name: 'content', title: 'Content' },
    { name: 'settings', title: 'Settings' },
    { name: 'advanced', title: 'Advanced' },
  ],

  fields: [
    // 🆔 Component ID
    defineField({
      name: 'componentId',
      title: 'Component ID',
      type: 'string',
      group: 'settings',
      validation: (Rule) => Rule.max(120),
    }),

    // 🔗 Anchor ID
    defineField({
      name: 'anchorId',
      title: 'Anchor ID',
      type: 'string',
      group: 'settings',
      validation: (Rule) =>
        Rule.regex(/^[A-Za-z][-A-Za-z0-9_:.]*$/),
    }),

    // 📝 Title
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      group: 'content',
      validation: (Rule) => Rule.max(180),
    }),

    // ⚙️ Format switch
    defineField({
      name: 'format',
      title: 'Content Type',
      type: 'string',
      group: 'settings',
      options: {
        list: [
          { title: 'Rich Text', value: 'rich' },
          { title: 'Raw HTML (Advanced)', value: 'html' },
        ],
        layout: 'radio',
      },
      initialValue: 'rich',
      validation: (Rule) => Rule.required(),
    }),

    // 📄 Rich text
    defineField({
      name: 'contentRich',
      title: 'Rich Content',
      type: 'blockContent',
      group: 'content',
      hidden: ({ parent }) => parent?.format !== 'rich',
    }),

    // ⚠️ Raw HTML
    defineField({
      name: 'contentHtml',
      title: 'Raw HTML',
      type: 'text',
      rows: 10,
      group: 'advanced',
      description: '⚠️ Only for developers. HTML will be sanitized on frontend.',
      hidden: ({ parent }) => parent?.format !== 'html',
      validation: (Rule) =>
        Rule.custom((val, ctx) => {
          const parent = ctx.parent
          if (parent?.format === 'html' && !val) {
            return 'HTML is required when using Raw HTML'
          }
          return true
        }),
    }),

    // 🎨 Variant (NEW 🔥)
    defineField({
      name: 'variant',
      title: 'Style Variant',
      type: 'string',
      group: 'settings',
      options: {
        list: [
          { title: 'Default', value: 'default' },
          { title: 'Container', value: 'container' },
          { title: 'Narrow', value: 'narrow' },
          { title: 'Full Width', value: 'full' },
        ],
      },
      initialValue: 'default',
    }),

    // 📏 Spacing (NEW 🔥)
    defineField({
      name: 'spacing',
      title: 'Spacing',
      type: 'string',
      group: 'settings',
      options: {
        list: [
          { title: 'None', value: 'none' },
          { title: 'Small', value: 'sm' },
          { title: 'Medium', value: 'md' },
          { title: 'Large', value: 'lg' },
        ],
      },
      initialValue: 'md',
    }),

    // ♿ Accessibility (NEW 🔥)
    defineField({
      name: 'ariaLabel',
      title: 'ARIA Label',
      type: 'string',
      group: 'advanced',
      description: 'Describe this section for screen readers',
    }),
  ],

  preview: {
    select: {
      title: 'title',
      format: 'format',
      variant: 'variant',
    },
    prepare({ title, format, variant }) {
      return {
        title: title || 'HTML Block',
        subtitle: `${format === 'html' ? '⚠️ Raw HTML' : 'Rich Text'} • ${variant}`,
      }
    },
  },
})