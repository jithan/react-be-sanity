import { defineType, defineField } from "sanity";

export default defineType({
  name: "accordionGroup",
  title: "Accordion Group",
  type: "object",

  fields: [
    // 🆔 Optional anchor ID
    defineField({
      name: "componentId",
      title: "Component ID",
      type: "string",
      description: "Optional anchor ID for linking (#faq)",
    }),

    // 🧩 Accordion Items
    defineField({
      name: "items",
      title: "Accordion Items",
      type: "array",
      of: [{ type: "accordionItem" }],
      validation: (Rule) => Rule.required().min(1).max(20),
    }),

    // ⚙️ Behavior settings
    defineField({
      name: "allowMultipleOpen",
      title: "Allow multiple open",
      type: "boolean",
      initialValue: false,
    }),

    defineField({
      name: "defaultOpenFirst",
      title: "Open first item by default",
      type: "boolean",
      initialValue: false,
    }),
  ],

  preview: {
    select: {
      items: "items",
      firstTitle: "items.0.title",
    },
    prepare({ items, firstTitle }) {
      const count = items?.length || 0;

      return {
        title: `Accordion group (${count} item${count === 1 ? "" : "s"})`,
        subtitle: firstTitle ? `First: ${firstTitle}` : "No items yet",
      };
    },
  },
});