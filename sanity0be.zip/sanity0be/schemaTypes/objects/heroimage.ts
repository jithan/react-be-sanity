// schemas/Heroimage.ts
import {defineType, defineField} from 'sanity'
import {ImageIcon} from '@sanity/icons'

export default defineType({
  name: 'Heroimage',
  title: 'Hero Image',
  type: 'object',
  icon: ImageIcon,

  fields: [
    // 🆔 Component ID
    defineField({
      name: 'field_component_id',
      title: 'Component ID',
      type: 'string',
      validation: (Rule) => Rule.required().max(120),
    }),

    // 📝 Title (normal string)
    defineField({
      name: 'field_component_title',
      title: 'Title',
      type: 'string',
      validation: (Rule) => Rule.required().max(180),
    }),

    // 🏷️ Eyebrow
    defineField({
      name: 'field_component_title_eyebrow',
      title: 'Eyebrow',
      type: 'string',
      validation: (Rule) => Rule.max(120),
    }),

    // 🔗 Anchor ID
    defineField({
      name: 'data_id_for_anchor_linking',
      title: 'Data ID for anchor linking',
      type: 'string',
      validation: (Rule) =>
        Rule.regex(/^[A-Za-z][-A-Za-z0-9_:.]*$/).error(
          'Must be valid HTML id'
        ),
    }),

    // 📄 Description (Portable Text)
    defineField({
      name: 'field_component_description',
      title: 'Description',
      type: 'blockContent',
      validation: (Rule) => Rule.required(),
    }),

    // 🔗 CTA
    defineField({
      name: 'field_link',
      title: 'CTA',
      type: 'link',
    }),

    // ↔️ Alignment
    defineField({
      name: 'field_component_list_image_alignment',
      title: 'Image Alignment',
      type: 'string',
      options: {
        list: [
          {title: 'Left', value: 'left'},
          {title: 'Right', value: 'right'},
        ],
        layout: 'radio',
      },
      initialValue: 'left',
      validation: (Rule) => Rule.required(),
    }),

    // 🖼️ Image
    defineField({
      name: 'image_field',
      title: 'Image',
      type: 'image',
      options: {hotspot: true},
      fields: [
        defineField({
          name: 'alt',
          title: 'Alt text',
          type: 'string',
          validation: (Rule) => Rule.required().min(5).max(160),
        }),
      ],
      validation: (Rule) => Rule.required(),
    }),

    // 🏷️ Logo (optional)
    defineField({
      name: 'logo_service_pillar_sm',
      title: 'Logo',
      type: 'image',
      options: {hotspot: true},
      fields: [
        defineField({
          name: 'alt',
          title: 'Alt text',
          type: 'string',
          validation: (Rule) => Rule.max(160),
        }),
      ],
    }),
  ],

  preview: {
    select: {
      title: 'field_component_title',
      media: 'image_field',
      subtitle: 'field_component_title_eyebrow',
    },
  },
})