import {defineType, defineField} from 'sanity'

export default defineType({
  name: 'megaMenuItem',
  title: 'Mega Menu Item',
  type: 'object',

  fields: [
    // 🖼️ Icon
    defineField({
      name: 'icon',
      title: 'Icon',
      type: 'image',
      options: {hotspot: true},
      fields: [
        defineField({
          name: 'alt',
          title: 'Alt text',
          type: 'string',
          validation: (Rule) => Rule.max(120),
        }),
      ],
    }),

    // 📝 Title
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (Rule) => Rule.required(),
    }),

    // 🧾 Description
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      rows: 2,
    }),

    // 🔗 Link (flexible)
    defineField({
      name: 'link',
      title: 'Link',
      type: 'object',
      fields: [
        defineField({
          name: 'internal',
          title: 'Internal Page',
          type: 'reference',
          to: [
            {type: 'page'},
            {type: 'services'},
            {type: 'landingpage'},
          ],
        }),
        defineField({
          name: 'external',
          title: 'External URL',
          type: 'url',
        }),
        defineField({
          name: 'target',
          title: 'Target',
          type: 'string',
          options: {
            list: [
              {title: 'Same tab', value: '_self'},
              {title: 'New tab', value: '_blank'},
            ],
          },
          initialValue: '_self',
        }),
      ],
    }),
  ],

  preview: {
    select: {
      title: 'title',
      subtitle: 'description',
      media: 'icon',
    },
  },
})