import {defineType, defineField} from 'sanity'

export default defineType({
  name: 'megaMenuColumn',
  title: 'Mega Menu Column',
  type: 'object',

  fields: [
    // 📝 Column Title
    defineField({
      name: 'title',
      title: 'Column Title',
      type: 'string',
      validation: (Rule) => Rule.max(80),
    }),

    // 🔗 Links
    defineField({
      name: 'links',
      title: 'Links',
      type: 'array',
      of: [{type: 'megaMenuItem'}],
      validation: (Rule) => Rule.required().min(1).max(10),
    }),

    // 🌟 Optional Highlight CTA
    defineField({
      name: 'highlight',
      title: 'Highlight CTA',
      type: 'object',
      fields: [
        defineField({
          name: 'label',
          title: 'Label',
          type: 'string',
        }),
        defineField({
          name: 'url',
          title: 'URL',
          type: 'url',
        }),
      ],
    }),

    // 📐 Layout control
    defineField({
      name: 'columnWidth',
      title: 'Column Width',
      type: 'string',
      options: {
        list: [
          {title: 'Auto', value: 'auto'},
          {title: 'Small', value: 'sm'},
          {title: 'Medium', value: 'md'},
          {title: 'Large', value: 'lg'},
        ],
      },
      initialValue: 'auto',
    }),
  ],

  preview: {
    select: {
      title: 'title',
      links: 'links',
    },
    prepare({title, links}) {
      return {
        title: title || 'Mega Menu Column',
        subtitle: `${links?.length || 0} links`,
      }
    },
  },
})