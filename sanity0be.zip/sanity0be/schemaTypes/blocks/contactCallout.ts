import {defineField, defineType} from 'sanity'
import {MdContactMail as icon} from 'react-icons/md'

export default defineType({
  name: 'contactCallout',
  title: 'Contact Callout',
  type: 'object',
  icon,

  fields: [
    // 📝 Title
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (Rule) => Rule.required(),
    }),

    // 📄 Description
    defineField({
      name: 'description',
      title: 'Description',
      type: 'blockContent',
      validation: (Rule) => Rule.required(),
    }),

    // 🔘 CTA (clean object)
    defineField({
      name: 'cta',
      title: 'CTA Button',
      type: 'object',
      fields: [
        defineField({
          name: 'label',
          title: 'Button text',
          type: 'string',
          validation: (Rule) => Rule.required(),
        }),
        defineField({
          name: 'url',
          title: 'Button URL',
          type: 'url',
          validation: (Rule) => Rule.required(),
        }),
        defineField({
          name: 'target',
          title: 'Button target',
          type: 'string',
          options: {
            list: [
              {title: 'Same tab', value: '_self'},
              {title: 'New tab', value: '_blank'},
            ],
            layout: 'radio',
          },
          initialValue: '_self',
        }),
      ],
    }),
  ],

  preview: {
    select: {
      title: 'title',
      description: 'description',
    },
    prepare({title, description}) {
      // simple preview text extraction
      const plainText =
        description?.[0]?.children?.map((child) => child.text).join('') || ''

      return {
        title: title || 'Contact Callout',
        subtitle: plainText
          ? `${plainText.slice(0, 80)}...`
          : 'Contact callout block',
      }
    },
  },
})