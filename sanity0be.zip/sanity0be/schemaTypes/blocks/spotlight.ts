import {defineField, defineType} from 'sanity'
import {MdViewHeadline as icon} from 'react-icons/md'

export default defineType({
  name: 'spotlight',
  title: 'Spotlight Section',
  type: 'object',
  icon,

  fields: [
    // 📝 Title
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),

    // 🧾 Subtitle
    defineField({
      name: 'subtitle',
      title: 'Subtitle',
      type: 'text',
      rows: 2,
    }),

    // 🖼️ Image
    defineField({
      name: 'spotlightImage',
      title: 'Spotlight Image',
      type: 'image',
      options: {hotspot: true},
    }),

    // 🔘 CTA
    defineField({
      name: 'cta',
      title: 'CTA Button',
      type: 'object',
      fields: [
        defineField({
          name: 'label',
          title: 'Button Text',
          type: 'string',
        }),
        defineField({
          name: 'url',
          title: 'Button URL',
          type: 'url',
        }),
        defineField({
          name: 'target',
          title: 'Target',
          type: 'string',
          options: {
            list: [
              {title: 'Same tab', value: '_self'},
              {title: 'New tab', value: '_blank'},
            ],
          },
          initialValue: '_self',
        }),
      ],
    }),
  ],

  preview: {
    select: {
      title: 'title',
      subtitle: 'subtitle',
      media: 'spotlightImage', // ✅ fixed
    },
    prepare({title, subtitle, media}) {
      return {
        title: title || 'Spotlight Section',
        subtitle: subtitle || 'Spotlight Section',
        media: media || icon,
      }
    },
  },
})