import {defineField, defineType} from 'sanity'
import {MdImage as icon} from 'react-icons/md'

export default defineType({
  name: 'splitImage',
  title: 'Split Image Section',
  type: 'object',
  icon,

  fields: [
    // 📝 Title
    defineField({
      name: 'title',
      title: 'Section Title',
      type: 'string',
    }),

    // 📄 Content
    defineField({
      name: 'content',
      title: 'Content',
      type: 'blockContent',
    }),

    // 🖼️ Image
    defineField({
      name: 'image',
      title: 'Image',
      type: 'image',
      options: {hotspot: true},
      validation: (rule) => rule.required(),
    }),

    // ↔️ Image Position
    defineField({
      name: 'imagePosition',
      title: 'Image Position',
      type: 'string',
      options: {
        list: [
          {title: 'Left', value: 'left'},
          {title: 'Right', value: 'right'},
        ],
        layout: 'radio',
      },
      initialValue: 'right',
    }),

    // 🔘 CTA
    defineField({
      name: 'cta',
      title: 'CTA',
      type: 'object',
      fields: [
        defineField({name: 'label', title: 'Text', type: 'string'}),
        defineField({name: 'url', title: 'URL', type: 'url'}),
      ],
    }),
  ],

  preview: {
    select: {
      title: 'title',
      image: 'image',
      imagePosition: 'imagePosition',
    },
    prepare({title, image, imagePosition}) {
      return {
        title: title || 'Split Image Section',
        subtitle: `Image ${imagePosition || 'right'}`,
        media: image || icon,
      }
    },
  },
})