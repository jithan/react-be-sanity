import {defineField, defineType} from 'sanity'
import {MdViewHeadline as icon} from 'react-icons/md'

export default defineType({
  name: 'hero',
  title: 'Hero Section',
  type: 'object',
  icon,

  fields: [
    // 📝 Title
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (rule) => rule.required(),
    }),

    // 🧾 Subtitle
    defineField({
      name: 'subtitle',
      title: 'Subtitle',
      type: 'text',
      rows: 2,
    }),

    // 🖼️ Background Image
    defineField({
      name: 'backgroundImage',
      title: 'Background Image',
      type: 'image',
      options: {hotspot: true},
    }),

    // 🔘 CTA (grouped)
    defineField({
      name: 'cta',
      title: 'CTA Button',
      type: 'object',
      fields: [
        defineField({
          name: 'label',
          title: 'Button Text',
          type: 'string',
        }),
        defineField({
          name: 'url',
          title: 'Button URL',
          type: 'url',
        }),
        defineField({
          name: 'target',
          title: 'Target',
          type: 'string',
          options: {
            list: [
              {title: 'Same tab', value: '_self'},
              {title: 'New tab', value: '_blank'},
            ],
          },
          initialValue: '_self',
        }),
      ],
    }),

    // ↔️ Alignment
    defineField({
      name: 'align',
      title: 'Text Alignment',
      type: 'string',
      options: {
        list: [
          {title: 'Left', value: 'left'},
          {title: 'Center', value: 'center'},
          {title: 'Right', value: 'right'},
        ],
        layout: 'radio',
      },
      initialValue: 'center',
    }),
  ],

  preview: {
    select: {
      title: 'title',
      subtitle: 'subtitle',
      media: 'backgroundImage',
    },
    prepare({title, subtitle, media}) {
      return {
        title: title || 'Hero Section',
        subtitle: subtitle || 'Hero Section',
        media: media || icon,
      }
    },
  },
})