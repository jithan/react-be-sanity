import blockContent from './blockContent'

// 📄 Documents
import person from './person'
import article from './article'
import page from './page'
import services from './services'
import landingpage from './Landingpage'

// 🎬 Media
import kalturaVideo from './kalturaVideo'

// 🧱 Page Builder
import pageBuilderType from './pageBuilderType'

// 🧩 Blocks (Reusable Sections)
import hero from './blocks/hero'
import ctaCardPanel from './blocks/ctaCardPanel'
import features from './blocks/features'
import textSection from './blocks/textSection'
import splitImage from './blocks/splitImage'
import contactCallout from './blocks/contactCallout'

// 🧩 Components (Atoms / Molecules)
import Anchor_links from './objects/Anchor_links'
import Heroimage from './objects/heroimage'
import link from './objects/link'
import linkWithIcon from './objects/linkWithIcon'
import FullwidthImage from './objects/FullwidthImage'
import SpotlightContentService from './objects/SpotlightContentService'
import HTMLBlock from './objects/HTMLBlock'
import TwoColumn from './objects/TwoColumn'
import CustomImage from './objects/CustomImage'

// 📚 Content Modules
import topicItem from './objects/topicItem'
import topicsSection from './objects/topicsSection'
import accordionItem from './objects/accordionItem'
import accordionGroup from './objects/accordionGroup'
import searchBlock from './objects/searchBlock'

// 🧭 Navigation
import megaMenu from './navigation/megaMenu'
import megaMenuColumn from './navigation/megaMenuColumn'
import megaMenuItem from './navigation/megaMenuItem'

// 📚 Sidebar
import sidebar from './sidebar/sidebar'
import sidebarsection from './sidebar/sidebarSection'

export const schemaTypes = [
  // 📄 Documents
  person,
  article,
  page,
  services,
  landingpage,

  // 🧭 Navigation
  megaMenu,
  megaMenuColumn,
  megaMenuItem,

  // 🧱 Page Builder
  pageBuilderType,

  // 🧩 Blocks
  hero,
  features,
  textSection,
  splitImage,
  ctaCardPanel,
  contactCallout,

  // 🧩 Components
  Anchor_links,
  Heroimage,
  link,
  linkWithIcon,
  FullwidthImage,
  SpotlightContentService,
  HTMLBlock,
  TwoColumn,
  CustomImage,

  // 📚 Content Modules
  topicItem,
  topicsSection,
  accordionItem,
  accordionGroup,
  searchBlock,

  // 📚 Sidebar
  sidebar,
  sidebarsection,

  // 🎬 Media
  kalturaVideo,

  // 🧠 Shared
  blockContent,
]