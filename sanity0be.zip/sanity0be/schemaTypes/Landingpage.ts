import { defineType, defineField } from 'sanity'
import { DocumentsIcon } from '@sanity/icons'

export default defineType({
  name: 'landingpage',
  title: 'Landing Page',
  type: 'document',
  icon: DocumentsIcon,

  groups: [
    { name: 'content', title: 'Content' },
    { name: 'seo', title: 'SEO' },
    { name: 'settings', title: 'Settings' },
  ],

  fields: [
    // 📝 Title
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      group: 'content',
      validation: (Rule) => Rule.required().max(180),
    }),

    // 🔗 Slug
    defineField({
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      group: 'settings',
      options: {
        source: 'title',
        maxLength: 96,
        isUnique: (slug, context) => {
          const { document, getClient } = context

          if (!slug) return true
          if (!document?._id) return true // ✅ FIX

          const client = getClient({ apiVersion: '2023-01-01' })
          const id = document._id.replace(/^drafts\./, '')

          return client.fetch(
            `count(*[
      _type == "landingpage" &&
      slug.current == $slug &&
      !(_id in [$id, "drafts." + $id])
    ]) == 0`,
            { slug, id }
          )
        }
      },
      validation: (Rule) => Rule.required(),
    }),

    // 📅 Published date
    defineField({
      name: 'publishedAt',
      title: 'Published at',
      type: 'datetime',
      group: 'settings',
      initialValue: () => new Date().toISOString(),
    }),

    // 👁️ Visibility (NEW 🔥)
    defineField({
      name: 'isPublished',
      title: 'Publish Page',
      type: 'boolean',
      initialValue: true,
      group: 'settings',
    }),

    // ✏️ Excerpt
    defineField({
      name: 'excerpt',
      title: 'Excerpt',
      type: 'text',
      group: 'content',
      validation: (Rule) => Rule.max(220),
    }),

    // 🧩 Components
    defineField({
      name: 'components',
      title: 'Page Components',
      type: 'array',
      group: 'content',
      of: [
        { type: 'Heroimage' },
        { type: 'Anchor_links' },
        { type: 'FullwidthImage' },
        { type: 'SpotlightContentService' },
        { type: 'twoColumn' },
      ],
      validation: (Rule) => Rule.required().min(1),
      options: { sortable: true },
    }),

    // 🔍 SEO (NEW 🔥)
    defineField({
      name: 'seo',
      title: 'SEO Settings',
      type: 'object',
      group: 'seo',
      fields: [
        defineField({
          name: 'metaTitle',
          title: 'Meta Title',
          type: 'string',
          validation: (Rule) => Rule.max(60),
        }),
        defineField({
          name: 'metaDescription',
          title: 'Meta Description',
          type: 'text',
          rows: 3,
          validation: (Rule) => Rule.max(160),
        }),
        defineField({
          name: 'ogImage',
          title: 'Open Graph Image',
          type: 'image',
          options: { hotspot: true },
        }),
      ],
    }),
  ],

  preview: {
    select: {
      title: 'title',
      slug: 'slug.current',
      lang: '__i18n_lang',
      published: 'isPublished',
    },
    prepare({ title, slug, lang, published }) {
      return {
        title: `${title || 'Untitled'} (${lang || 'no-lang'})`,
        subtitle: `${published ? '✅' : '❌'} ${slug ? `/${slug}` : 'No slug'}`,
      }
    },
  },
})