import { createClient } from '@sanity/client'

import { createClient } from '@sanity/client'

const client = createClient({
  projectId: 'lyl5ivou',
  dataset: 'production',
  useCdn: false,
  apiVersion: '2024-01-01',
  // For local development, we might not need a token
})

// Sample services data with English and German content
const servicesData = [
  {
    _type: 'services',
    _id: 'health-insurance-service',
    title: [
      { _type: 'internationalizedArrayStringValue', _key: 'en', value: 'Health Insurance Coverage' },
      { _type: 'internationalizedArrayStringValue', _key: 'de', value: 'Krankenversicherungsschutz' }
    ],
    description: [
      {
        _type: 'internationalizedArrayTextValue',
        _key: 'en',
        value: 'Comprehensive health insurance plans designed to protect you and your family. Our coverage includes preventive care, hospitalization, prescription drugs, and emergency services. Choose from individual, family, or group plans tailored to your needs.'
      },
      {
        _type: 'internationalizedArrayTextValue',
        _key: 'de',
        value: 'Umfassende Krankenversicherungspläne, die Sie und Ihre Familie schützen. Unsere Deckung umfasst Vorsorgeuntersuchungen, Krankenhausaufenthalte, verschreibungspflichtige Medikamente und Notfalldienste. Wählen Sie aus individuellen, Familien- oder Gruppenplänen, die auf Ihre Bedürfnisse zugeschnitten sind.'
      }
    ],
    category: 'insurance',
    featured: true,
    publishedAt: new Date().toISOString()
  },
  {
    _type: 'services',
    _id: 'dental-insurance-service',
    title: [
      { _type: 'internationalizedArrayStringValue', _key: 'en', value: 'Dental Care Insurance' },
      { _type: 'internationalizedArrayStringValue', _key: 'de', value: 'Zahnversicherung' }
    ],
    description: [
      {
        _type: 'internationalizedArrayTextValue',
        _key: 'en',
        value: 'Complete dental coverage for routine checkups, cleanings, fillings, and major procedures. Our dental plans include orthodontic coverage for children and preventive care benefits to maintain healthy teeth and gums.'
      },
      {
        _type: 'internationalizedArrayTextValue',
        _key: 'de',
        value: 'Vollständige Zahnversorgung für Routineuntersuchungen, Reinigungen, Füllungen und größere Eingriffe. Unsere Zahnpläne umfassen kieferorthopädische Leistungen für Kinder und Vorsorgeleistungen zur Erhaltung gesunder Zähne und Zahnfleisches.'
      }
    ],
    category: 'insurance',
    featured: true,
    publishedAt: new Date().toISOString()
  },
  {
    _type: 'services',
    _id: 'medical-services-directory',
    title: [
      { _type: 'internationalizedArrayStringValue', _key: 'en', value: 'Medical Services Directory' },
      { _type: 'internationalizedArrayStringValue', _key: 'de', value: 'Medizinisches Diensteverzeichnis' }
    ],
    description: [
      {
        _type: 'internationalizedArrayTextValue',
        _key: 'en',
        value: 'Find qualified healthcare providers in your area. Our directory includes primary care physicians, specialists, hospitals, clinics, and urgent care centers. Search by location, specialty, and insurance acceptance.'
      },
      {
        _type: 'internationalizedArrayTextValue',
        _key: 'de',
        value: 'Finden Sie qualifizierte Gesundheitsdienstleister in Ihrer Region. Unser Verzeichnis umfasst Hausärzte, Fachärzte, Krankenhäuser, Kliniken und Notfallzentren. Suchen Sie nach Standort, Fachgebiet und Versicherungsakzeptanz.'
      }
    ],
    category: 'directory',
    featured: false,
    publishedAt: new Date().toISOString()
  },
  {
    _type: 'services',
    _id: 'prescription-drug-coverage',
    title: [
      { _type: 'internationalizedArrayStringValue', _key: 'en', value: 'Prescription Drug Coverage' },
      { _type: 'internationalizedArrayStringValue', _key: 'de', value: 'Verschreibungspflichtige Arzneimittelversorgung' }
    ],
    description: [
      {
        _type: 'internationalizedArrayTextValue',
        _key: 'en',
        value: 'Affordable prescription drug coverage with access to a wide network of pharmacies. Our plans include generic drug incentives, mail-order options, and coverage for both brand-name and generic medications.'
      },
      {
        _type: 'internationalizedArrayTextValue',
        _key: 'de',
        value: 'Erschwingliche Versorgung mit verschreibungspflichtigen Arzneimitteln mit Zugang zu einem breiten Netzwerk von Apotheken. Unsere Pläne umfassen Anreize für Generika, Versandoptionen und Deckung für Marken- und Generikamedikamente.'
      }
    ],
    category: 'insurance',
    featured: false,
    publishedAt: new Date().toISOString()
  }
]

async function importServices() {
  console.log('Starting import of sample services...')

  for (const service of servicesData) {
    try {
      const result = await client.createOrReplace(service)
      console.log(`Imported service: ${result._id}`)
    } catch (error) {
      console.error(`Failed to import service ${service._id}:`, error.message)
    }
  }

  console.log('Import completed!')
}

// Run the import
importServices().catch(console.error)